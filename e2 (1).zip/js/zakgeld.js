document.getElementById("knop").addEventListener("click",berekenzakgeld);
let totaalzakgeld = 0;

function berekenzakgeld () {
  const zakgeldperweek =Number(document.getElementById("zakgeld").value);
  const div =document.getElementById("zakgeldcontnent");
  for(let i=1; i<=10; i++) {
    totaalzakgeld= totaalzakgeld + zakgeldperweek;
    let boodschapinhoud ="week" + i + ":  "+totaalzakgeld;
    if(totaalzakgeld >=60) {
      boodschapinhoud = boodschapinhoud + ",hiermee kan je game kopen";
    } else if(totaalzakgeld>45) {
      boodschapinhoud = boodschapinhoud + ",hiermee kan je laptop kopen";
    } else if (totaalzakgeld>=30) {
       boodschapinhoud = boodschapinhoud + ",hiermee kan je knuffel kopen";
    } else if (totaalzakgeld>=15) {
      boodschapinhoud = boodschapinhoud + ",hiermee kan je computermuis kopen";
    }
    else if (totaalzakgeld>=10) {
      boodschapinhoud = boodschapinhoud + ",hiermee kan je snoep kopen";
    }
     else if (totaalzakgeld>=5) {

     } else {}
    let p = document.createElement("p");
    p.innerHTML =boodschapinhoud;
    div.appendChild(p);
  }
}