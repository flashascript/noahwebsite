let neieuweElement =document.createElement("p")
let hey =document.getElementById("hey")
 hey.innerHTML = "heeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeey"
let div =document.getElementById("div")
div.innerHTML ="heey"