for(let i=0;i<5;i++){
  alert("je hebt het voorbeeldscript goed gelinkt");
}
