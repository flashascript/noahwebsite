document.getElementById("button").addEventListener("click", startteller);

function startteller () {
    
   let doel =document.getElementbyId("teller").value
  document.createElement(strong)
  let tel =0;
  
  

while(tel<doel*1000000) {

  tel +=1;
  
}
  document.getElementById("tel").innerHTML =tel;
  
}