document.getElementById("tekst2").addEventListener("click", tekstveranderen);

function tekstveranderen() {
  let nieuwetekst = document.getElementById("tekst2");
  nieuwetekst.innerHTML = "dit is een js tekst";
}
document.getElementById("magieknop").addEventListener("click", pastekstaan);

function pastekstaan(){
  let tekst = document.getElementById("aantepassentekst");
  tekst.innerHTML = "Deze tekst verschijnt via JavaScript!";
}
